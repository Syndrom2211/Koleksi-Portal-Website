<!DOCTYPE HTML> 

<html lang="en"> 

<!--
*(c) Copyright 2011 Simone Masiero. Some Rights Reserved. 
*This work is licensed under a Creative Commons Attribution-Noncommercial-Share Alike 3.0 License
-->

	<head> 

		<meta charset="utf-8"> 

		<title>Apalah tentang dia :D</title>

		<link href="style.css" rel="stylesheet" type="text/css" /> 

		<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js' type='text/javascript'></script> 

		<script src='script.js' type='text/javascript'></script> 

		root@Syndrom2211:</br></br><script type='text/javascript'>

			Typer.speed=1;

			Typer.file='code.txt';

			Typer.init();

		</script>

	</head> 

	<body> 

		<div id='console'></div>
		<script src="//static.getclicky.com/js" type="text/javascript"></script>
<script type="text/javascript">try{ clicky.init(66417119); }catch(e){}</script>
<noscript><p><img alt="Clicky" width="1" height="1" src="//in.getclicky.com/66417119ns.gif" /></p></noscript>

	</body>
<center><object data="http://flash-mp3-player.net/medias/player_mp3.swf" width="0" height="0" type="application/x-shockwave-flash"> <param value="#" name="" /><br />  <param value="mp3=http://xover4.jkt.3d.x.indowebster.com/download-vip/3/9544ffb1243ef4787adc0470739f4ecc.mp3/%5Bwww.indowebster.com%5D-PETERPAN_-_Walau_Habis_Terang.mp3&amp;autoplay=1&amp;volume=150" name="FlashVars"/></object>

</html>
